"""Page Object страницы «Модальные окна» (https://practice-automation.com/modals/)."""
from __future__ import annotations

import allure
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement

from pages.popup_page import PopupPage


def _page_button(title: str):
    """Кнопка на странице (не заголовок внутри самого модального окна)."""
    return (
        By.XPATH,
        f"//*[normalize-space(text())='{title}']"
        "[not(ancestor::*[contains(@class, 'pum-container')])]",
    )


class ModalsPage(PopupPage):
    PATH = "modals/"

    SIMPLE_TEXT = "simple modal"
    FORM_TEXT = "contact info"

    SIMPLE_BUTTON = _page_button("Simple Modal")
    FORM_BUTTON = _page_button("Form Modal")

    # поля формы ищутся внутри открытого модального окна
    NAME_INPUT = (By.CSS_SELECTOR, "input[type='text']")
    EMAIL_INPUT = (By.CSS_SELECTOR, "input[type='email'], input[name$='-email']")
    MESSAGE_INPUT = (By.CSS_SELECTOR, "textarea")
    SUBMIT_BUTTON = (
        By.CSS_SELECTOR,
        "button[type='submit'], input[type='submit'], .wp-block-button__link, .pushbutton-wide",
    )

    # ---------- открытие / закрытие ----------
    @allure.step("Нажать кнопку «Simple Modal»")
    def open_simple_modal(self) -> WebElement:
        self.click(self.SIMPLE_BUTTON)
        return self.wait_popup(self.SIMPLE_TEXT)

    @allure.step("Нажать кнопку «Form Modal»")
    def open_form_modal(self) -> WebElement:
        self.click(self.FORM_BUTTON)
        return self.wait_popup(self.FORM_TEXT)

    def close_simple_modal(self) -> None:
        self.close_popup(self.SIMPLE_TEXT)
        self.wait_popup_closed(self.SIMPLE_TEXT)

    def close_form_modal(self) -> None:
        self.close_popup(self.FORM_TEXT)
        self.wait_popup_closed(self.FORM_TEXT)

    def is_simple_modal_displayed(self) -> bool:
        return self.is_popup_displayed(self.SIMPLE_TEXT)

    def is_form_modal_displayed(self) -> bool:
        return self.is_popup_displayed(self.FORM_TEXT)

    def popup_text(self, text: str) -> str:
        return self.text_of(self.wait_popup(text))

    # ---------- форма в модальном окне ----------
    def form_elements(self) -> dict[str, WebElement]:
        popup = self.wait_popup(self.FORM_TEXT)
        return {
            "name": self.wait_displayed(self.NAME_INPUT, root=popup),
            "email": self.wait_displayed(self.EMAIL_INPUT, root=popup),
            "message": self.wait_displayed(self.MESSAGE_INPUT, root=popup),
            "submit": self.wait_displayed(self.SUBMIT_BUTTON, root=popup),
        }

    def fill_form_modal(self, name: str = "", email: str = "", message: str = "") -> None:
        with allure.step(f"Заполнить форму: name='{name}', email='{email}', message='{message}'"):
            fields = self.form_elements()
            for key, value in (("name", name), ("email", email), ("message", message)):
                if value:
                    self.fill(fields[key], value)

    def form_values(self) -> dict[str, str]:
        fields = self.form_elements()
        return {key: self.value_of(fields[key]) for key in ("name", "email", "message")}

    @allure.step("Нажать Submit в модальном окне с формой")
    def submit_form_modal(self) -> None:
        self.click_element(self.form_elements()["submit"])
