"""Page Object страницы с формой (https://practice-automation.com/form-fields/)."""
from __future__ import annotations

import allure
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait

from pages.base_page import BasePage

LOWER = "translate(normalize-space(text()), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz')"


class FormFieldsPage(BasePage):
    PATH = "form-fields/"

    NAME = (By.CSS_SELECTOR, "#name-input, input[name='name-input']")
    PASSWORD = (By.CSS_SELECTOR, "#password, input[type='password']")
    EMAIL = (By.CSS_SELECTOR, "#email, input[name='email']")
    MESSAGE = (By.CSS_SELECTOR, "#message, #feedbackForm textarea")
    SUBMIT = (By.CSS_SELECTOR, "#submit-btn, #feedbackForm button[type='submit']")
    AUTOMATION_SELECT = (By.CSS_SELECTOR, "#automation, select[name='automation']")

    # Элементы списка из раздела «Automation tools»
    TOOLS = (By.XPATH, f"//*[contains({LOWER}, 'automation tools')]/following::ul[1]/li")

    @staticmethod
    def drink(title: str):
        return (By.CSS_SELECTOR, f"input[type='checkbox'][value='{title}']")

    @staticmethod
    def color(title: str):
        return (By.CSS_SELECTOR, f"input[type='radio'][value='{title}']")

    # ---------- заполнение ----------
    @allure.step("Заполнить обязательное поле Name: {value}")
    def fill_name(self, value: str) -> None:
        self.fill(self.wait_displayed(self.NAME), value)

    @allure.step("Заполнить поле Password")
    def fill_password(self, value: str) -> None:
        self.fill(self.wait_displayed(self.PASSWORD), value)

    @allure.step("Заполнить поле Email: {value}")
    def fill_email(self, value: str) -> None:
        self.fill(self.wait_displayed(self.EMAIL), value)

    @allure.step("Заполнить поле Message: {value}")
    def fill_message(self, value: str) -> None:
        self.fill(self.wait_displayed(self.MESSAGE), value)

    def message_value(self) -> str:
        return self.value_of(self.wait_displayed(self.MESSAGE))

    # ---------- Automation tools ----------
    @allure.step("Получить список элементов из раздела «Automation tools»")
    def get_automation_tools(self) -> list[str]:
        WebDriverWait(self.driver, self.timeout).until(lambda d: d.find_elements(*self.TOOLS))
        return [self.text_of(item) for item in self.driver.find_elements(*self.TOOLS)]

    @allure.step("Заполнить Message списком Automation tools через запятую")
    def fill_message_with_automation_tools(self) -> str:
        tools = self.get_automation_tools()
        text = ", ".join(tools)
        self.fill_message(text)
        return text

    # ---------- чекбоксы, радиокнопки, выпадающий список ----------
    def choose_drink(self, title: str) -> WebElement:
        with allure.step(f"Отметить напиток: {title}"):
            checkbox = self.wait_displayed(self.drink(title))
            if not checkbox.is_selected():
                self.click_element(checkbox)
            return checkbox

    def choose_color(self, title: str) -> WebElement:
        with allure.step(f"Выбрать цвет: {title}"):
            radio = self.wait_displayed(self.color(title))
            self.click_element(radio)
            return radio

    def choose_automation_answer(self, option: str) -> str:
        with allure.step(f"Выбрать в списке «Do you like automation?»: {option}"):
            select = Select(self.wait_displayed(self.AUTOMATION_SELECT))
            select.select_by_visible_text(option)
            return select.first_selected_option.text

    # ---------- отправка ----------
    @allure.step("Нажать кнопку Submit")
    def submit(self) -> None:
        self.click(self.SUBMIT)

    def accept_alert(self, timeout: float = 5) -> str | None:
        """Принимает alert и возвращает его текст; None, если alert не появился."""
        try:
            alert = WebDriverWait(self.driver, timeout).until(EC.alert_is_present())
        except TimeoutException:
            return None
        text = alert.text
        alert.accept()
        return text
