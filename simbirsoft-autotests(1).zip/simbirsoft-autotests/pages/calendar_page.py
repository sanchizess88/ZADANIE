"""Page Object страницы «Календарь» (https://practice-automation.com/calendars/).

Поле даты — Jetpack Forms с собственным виджетом календаря (классы dp-*):
 - календарь открывается по фокусу на поле и удаляется из DOM при закрытии;
 - формат даты YYYY-MM-DD;
 - некорректная дата не блокируется при вводе, а подсвечивается ошибкой после ухода из поля.
"""
from __future__ import annotations

from datetime import date

import allure
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait

from pages.base_page import BasePage

MONTHS = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
]


class CalendarPage(BasePage):
    PATH = "calendars/"

    DATE_INPUT = (By.CSS_SELECTOR, "input.jp-contact-form-date")

    # Виджет календаря
    PICKER = (By.CSS_SELECTOR, ".dp-cal")
    MONTH_LABEL = (By.CSS_SELECTOR, ".dp-cal .dp-cal-month")
    YEAR_LABEL = (By.CSS_SELECTOR, ".dp-cal .dp-cal-year")
    NEXT_MONTH = (By.CSS_SELECTOR, ".dp-cal .dp-next")
    PREV_MONTH = (By.CSS_SELECTOR, ".dp-cal .dp-prev")
    TODAY_CELL = (By.CSS_SELECTOR, ".dp-cal button.dp-day-today")
    SELECTED_CELL = (By.CSS_SELECTOR, ".dp-cal button.dp-selected")

    SUBMIT_BUTTON = (
        By.CSS_SELECTOR,
        "button[type='submit'], input[type='submit'], .wp-block-button__link, .pushbutton-wide",
    )

    # ---------- поле даты ----------
    @property
    def date_input(self) -> WebElement:
        return self.wait_displayed(self.DATE_INPUT)

    def get_date_value(self) -> str:
        return self.value_of(self.date_input)

    @allure.step("Ввести дату с клавиатуры: {text}")
    def type_date(self, text: str) -> None:
        self.fill(self.date_input, text)

    @allure.step("Покинуть поле даты (Tab)")
    def leave_field(self) -> None:
        self.date_input.send_keys(Keys.TAB)

    def field_has_error(self, timeout: float = 3) -> bool:
        """True, если у поля даты показана ошибка валидации (aria-invalid и блок has-errors)."""
        field = self.date_input
        wrapper = field.find_element(By.XPATH, "./ancestor::div[contains(@class, 'grunion-field-wrap')]")

        def has_error(_):
            errors = wrapper.find_elements(By.CSS_SELECTOR, ".contact-form__input-error.has-errors")
            return bool(errors) and field.get_attribute("aria-invalid") == "true"

        try:
            return bool(WebDriverWait(self.driver, timeout).until(has_error))
        except TimeoutException:
            return False

    # ---------- календарь ----------
    @allure.step("Открыть календарь кликом по полю даты")
    def open_picker(self) -> None:
        field = self.date_input
        for _ in range(3):
            # blur нужен, чтобы клик гарантированно вызвал focus; сразу после закрытия
            # виджет ~100 мс не открывается, поэтому предусмотрены повторные попытки
            self.driver.execute_script("arguments[0].blur();", field)
            self.click_element(field)
            try:
                self.wait_displayed(self.PICKER, timeout=2)
                return
            except TimeoutException:
                continue
        raise AssertionError("Календарь не открылся после клика по полю даты")

    def is_picker_displayed(self) -> bool:
        return self.is_displayed(self.PICKER)

    def displayed_month(self) -> tuple[int, int]:
        """(год, месяц 1-12), который сейчас показан в календаре."""
        month_name = self.text_of(self.wait_displayed(self.MONTH_LABEL))
        year = int(self.text_of(self.wait_displayed(self.YEAR_LABEL)))
        return year, MONTHS.index(month_name) + 1

    def go_to_month(self, year: int, month: int) -> None:
        """Пагинация календаря кнопками «Previous Month / Next Month»."""
        with allure.step(f"Перейти в календаре на {year}-{month:02d}"):
            current_year, current_month = self.displayed_month()
            diff = (year - current_year) * 12 + (month - current_month)
            button = self.NEXT_MONTH if diff > 0 else self.PREV_MONTH
            for _ in range(abs(diff)):
                self.click(button)
            assert self.displayed_month() == (year, month), "Календарь открыт не на том месяце"

    def pick_day(self, day: int) -> None:
        """Выбрать день в текущем отображаемом месяце (дни соседних месяцев игнорируются)."""
        with allure.step(f"Выбрать день {day}"):
            locator = (
                By.XPATH,
                "//div[contains(@class, 'dp-days')]//button"
                "[contains(concat(' ', normalize-space(@class), ' '), ' dp-day ')]"
                f"[not(contains(@class, 'dp-edge-day'))][normalize-space()='{day}']",
            )
            self.click(locator)
            self.wait_not_displayed(self.PICKER)

    def select_date(self, target: date) -> None:
        """Полный сценарий: открыть календарь → перейти на нужный месяц → выбрать день."""
        with allure.step(f"Выбрать в календаре дату {target.isoformat()}"):
            if not self.is_picker_displayed():
                self.open_picker()
            self.go_to_month(target.year, target.month)
            self.pick_day(target.day)

    def today_cell(self) -> WebElement:
        return self.wait_displayed(self.TODAY_CELL)

    def selected_cell(self) -> WebElement:
        return self.wait_displayed(self.SELECTED_CELL)

    # ---------- отправка формы ----------
    @allure.step("Нажать кнопку Submit")
    def submit(self) -> None:
        field = self.date_input
        if self.is_picker_displayed():
            field.send_keys(Keys.ESCAPE)  # календарь может перекрывать кнопку
            self.wait_not_displayed(self.PICKER)
        form = field.find_element(By.XPATH, "./ancestor::form")
        self.click_element(form.find_element(*self.SUBMIT_BUTTON))
