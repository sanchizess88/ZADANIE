"""Базовый Page Object: общие ожидания, клики и проверки видимости."""
from __future__ import annotations

import allure
from selenium.common.exceptions import (
    ElementClickInterceptedException,
    ElementNotInteractableException,
    StaleElementReferenceException,
    TimeoutException,
)
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait

import config

Locator = tuple[str, str]


class BasePage:
    PATH = ""

    # Jetpack всегда держит блок «Thank you for your response» в DOM (скрыт только через aria-hidden),
    # поэтому успех определяем по классу submission-success, который ставится после отправки формы.
    FORM_SUCCESS: Locator = (
        By.XPATH,
        "//*[contains(@class, 'contact-form-submission') and contains(@class, 'submission-success')]",
    )
    # Сообщение об ошибке валидации у поля формы (например, «This field is required.»)
    FIELD_ERROR: Locator = (
        By.XPATH,
        "//*[contains(@class, 'contact-form__input-error') and contains(@class, 'has-errors')]",
    )

    def __init__(self, driver: WebDriver, timeout: int = config.DEFAULT_TIMEOUT):
        self.driver = driver
        self.timeout = timeout

    # ---------- навигация ----------
    @property
    def url(self) -> str:
        return config.BASE_URL + self.PATH

    def open(self):
        with allure.step(f"Открыть страницу {self.url}"):
            self.driver.get(self.url)
        return self

    # ---------- поиск и ожидания ----------
    @staticmethod
    def _is_displayed(element: WebElement) -> bool:
        try:
            return element.is_displayed()
        except StaleElementReferenceException:
            return False

    def displayed_elements(self, locator: Locator, root: WebElement | None = None) -> list[WebElement]:
        context = root if root is not None else self.driver
        return [e for e in context.find_elements(*locator) if self._is_displayed(e)]

    def is_displayed(self, locator: Locator, root: WebElement | None = None) -> bool:
        return bool(self.displayed_elements(locator, root))

    def wait_displayed(
        self, locator: Locator, timeout: float | None = None, root: WebElement | None = None
    ) -> WebElement:
        """Ждёт, пока появится хотя бы один видимый элемент, и возвращает первый из них."""
        wait = WebDriverWait(self.driver, timeout or self.timeout)
        return wait.until(lambda _: next(iter(self.displayed_elements(locator, root)), False))

    def wait_not_displayed(
        self, locator: Locator, timeout: float | None = None, root: WebElement | None = None
    ) -> bool:
        """Ждёт, пока не останется ни одного видимого элемента. TimeoutException, если элемент не пропал."""
        wait = WebDriverWait(self.driver, timeout or self.timeout)
        return wait.until(lambda _: not self.displayed_elements(locator, root))

    def stays_displayed(self, locator: Locator, seconds: float) -> bool:
        """True, если элемент остаётся видимым всё указанное время."""
        try:
            self.wait_not_displayed(locator, timeout=seconds)
            return False
        except TimeoutException:
            return True

    def stays_hidden(self, locator: Locator, seconds: float) -> bool:
        """True, если за указанное время элемент ни разу не стал видимым."""
        try:
            self.wait_displayed(locator, timeout=seconds)
            return False
        except TimeoutException:
            return True

    # ---------- действия ----------
    def click_element(self, element: WebElement) -> None:
        self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", element)
        try:
            element.click()
        except (ElementClickInterceptedException, ElementNotInteractableException):
            self.driver.execute_script("arguments[0].click();", element)

    def click(self, locator: Locator) -> None:
        self.click_element(self.wait_displayed(locator))

    @staticmethod
    def fill(element: WebElement, text: str) -> None:
        element.clear()
        element.send_keys(text)

    @staticmethod
    def value_of(element: WebElement) -> str:
        return element.get_attribute("value") or ""

    @staticmethod
    def text_of(element: WebElement) -> str:
        """Текст элемента независимо от его видимости (textContent)."""
        return " ".join((element.get_attribute("textContent") or "").split())

    def is_unobstructed(self, element: WebElement) -> bool:
        """True, если в центре элемента нет перекрывающего слоя (оверлея, модального окна)."""
        script = """
            const el = arguments[0];
            el.scrollIntoView({block: 'center'});
            const r = el.getBoundingClientRect();
            const top = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
            return !!top && (el === top || el.contains(top));
        """
        return bool(self.driver.execute_script(script, element))

    # ---------- общие проверки формы ----------
    def wait_form_success(self, timeout: float | None = None) -> bool:
        """True, если форма успешно отправлена (появился класс submission-success)."""
        try:
            WebDriverWait(self.driver, timeout or self.timeout).until(
                lambda d: d.find_elements(*self.FORM_SUCCESS)
            )
            return True
        except TimeoutException:
            return False

    def has_field_errors(self) -> bool:
        """True, если у какого-либо поля формы показана ошибка валидации."""
        return bool(self.driver.find_elements(*self.FIELD_ERROR))
