"""Page Object страницы «Рекламные окна» (https://practice-automation.com/ads/)."""
from __future__ import annotations

import allure
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement

from pages.popup_page import PopupPage


class AdsPage(PopupPage):
    PATH = "ads/"

    AD_TEXT = "I am an ad"

    HEADING = (By.CSS_SELECTOR, "h1")
    COUNTDOWN_TEXT = (By.XPATH, "//*[contains(normalize-space(text()), 'An ad will appear in')]")
    HOW_TO_LINK = (By.XPATH, "//a[contains(normalize-space(.), 'how to handle ads')]")
    AD_TITLE = (By.XPATH, ".//*[normalize-space(text())='Hi']")
    AD_BODY = (By.XPATH, ".//*[contains(normalize-space(text()), 'I am an ad')]")

    # ---------- рекламное окно ----------
    @allure.step("Дождаться появления рекламного окна")
    def wait_ad(self, timeout: float = 15) -> WebElement:
        return self.wait_popup(self.AD_TEXT, timeout=timeout)

    def is_ad_displayed(self) -> bool:
        return self.is_popup_displayed(self.AD_TEXT)

    def ad_text(self) -> str:
        return self.text_of(self.wait_ad())

    def ad_title(self) -> WebElement:
        return self.wait_displayed(self.AD_TITLE, root=self.wait_ad())

    def ad_close_button(self) -> WebElement:
        return self.wait_displayed(self.CLOSE_BUTTON, root=self.wait_ad())

    @allure.step("Закрыть рекламное окно кнопкой «×»")
    def close_ad(self) -> None:
        self.click_element(self.ad_close_button())
        self.wait_popup_closed(self.AD_TEXT)

    @allure.step("Кликнуть по тексту внутри рекламного окна")
    def click_inside_ad(self) -> None:
        self.click_element(self.wait_displayed(self.AD_BODY, root=self.wait_ad()))

    def ad_stays_displayed(self, seconds: float) -> bool:
        return self.stays_displayed(self.popup_locator(self.AD_TEXT), seconds)

    def ad_stays_hidden(self, seconds: float) -> bool:
        return self.stays_hidden(self.popup_locator(self.AD_TEXT), seconds)

    # ---------- содержимое страницы ----------
    def heading(self) -> WebElement:
        return self.wait_displayed(self.HEADING)

    def countdown_element(self) -> WebElement:
        return self.wait_displayed(self.COUNTDOWN_TEXT)

    def how_to_link(self) -> WebElement:
        return self.wait_displayed(self.HOW_TO_LINK)

    def is_page_content_available(self) -> bool:
        """True, если заголовок страницы не перекрыт рекламным окном/оверлеем."""
        return self.is_unobstructed(self.heading())
