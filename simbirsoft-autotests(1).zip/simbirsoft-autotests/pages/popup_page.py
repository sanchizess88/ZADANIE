"""Общая логика для страниц, использующих всплывающие окна (Popup Maker): модальные и рекламные окна."""
from __future__ import annotations

import allure
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement

from pages.base_page import BasePage, Locator


class PopupPage(BasePage):
    CLOSE_BUTTON: Locator = (
        By.XPATH,
        ".//*[contains(@class, 'pum-close') or contains(@class, 'popmake-close') or @aria-label='Close']",
    )

    @staticmethod
    def popup_locator(text: str) -> Locator:
        """Всплывающее окно, содержащее указанный текст."""
        return (
            By.XPATH,
            "//*[contains(@class, 'pum-container') or @role='dialog']"
            f"[contains(normalize-space(.), '{text}')]",
        )

    def wait_popup(self, text: str, timeout: float | None = None) -> WebElement:
        return self.wait_displayed(self.popup_locator(text), timeout=timeout)

    def is_popup_displayed(self, text: str) -> bool:
        return self.is_displayed(self.popup_locator(text))

    def wait_popup_closed(self, text: str, timeout: float | None = None) -> bool:
        return self.wait_not_displayed(self.popup_locator(text), timeout=timeout)

    def close_popup(self, text: str) -> None:
        with allure.step("Закрыть всплывающее окно кнопкой «×»"):
            popup = self.wait_popup(text)
            self.click_element(self.wait_displayed(self.CLOSE_BUTTON, root=popup))
