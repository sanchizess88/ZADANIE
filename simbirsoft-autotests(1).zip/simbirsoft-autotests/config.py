"""Глобальные настройки проекта (можно переопределить переменными окружения)."""
import os

BASE_URL = os.getenv("BASE_URL", "https://practice-automation.com/").rstrip("/") + "/"
DEFAULT_TIMEOUT = int(os.getenv("DEFAULT_TIMEOUT", "15"))
