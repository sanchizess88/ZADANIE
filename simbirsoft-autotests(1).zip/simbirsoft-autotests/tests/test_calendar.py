"""Тесты страницы «Календарь»: https://practice-automation.com/calendars/"""
from datetime import date

import allure
import pytest

pytestmark = pytest.mark.calendar


def shift_month(base: date, offset: int) -> tuple[int, int]:
    """(год, месяц) через offset месяцев от base."""
    index = base.year * 12 + (base.month - 1) + offset
    return index // 12, index % 12 + 1


@allure.epic("practice-automation.com")
@allure.feature("Календарь")
class TestCalendarPositive:

    @pytest.mark.positive
    @allure.story("Открытие календаря")
    @allure.title("CAL-P1: календарь открывается при клике на поле даты")
    def test_picker_opens_on_click(self, calendar_page):
        with allure.step("Календарь изначально скрыт"):
            assert not calendar_page.is_picker_displayed()
        calendar_page.open_picker()
        with allure.step("Календарь отображается на странице"):
            assert calendar_page.is_picker_displayed()

    @pytest.mark.positive
    @allure.story("Выбор даты")
    @allure.title("CAL-P2: выбор дня в текущем месяце записывает дату в формате YYYY-MM-DD")
    def test_select_day_in_current_month(self, calendar_page):
        today = date.today()
        target = date(today.year, today.month, 15)
        calendar_page.select_date(target)
        with allure.step(f"В поле даты записано {target.isoformat()}, ошибок нет"):
            assert calendar_page.get_date_value() == target.isoformat()
            calendar_page.leave_field()
            assert not calendar_page.field_has_error(timeout=1)

    @pytest.mark.positive
    @allure.story("Пагинация календаря")
    @pytest.mark.parametrize("months_offset", [-1, 1, 12], ids=["prev-month", "next-month", "plus-year"])
    @allure.title("CAL-P3: выбор даты через пагинацию (смещение {months_offset} мес.)")
    def test_select_date_with_pagination(self, calendar_page, months_offset):
        year, month = shift_month(date.today(), months_offset)
        target = date(year, month, 20)
        calendar_page.select_date(target)
        with allure.step(f"В поле даты записано {target.isoformat()}"):
            assert calendar_page.get_date_value() == target.isoformat()

    @pytest.mark.positive
    @allure.story("Ввод даты вручную")
    @allure.title("CAL-P4: корректная дата, введённая с клавиатуры, принимается без ошибок")
    def test_type_valid_date(self, calendar_page):
        calendar_page.type_date("2025-12-31")
        calendar_page.leave_field()
        with allure.step("Значение сохранилось, ошибка валидации не показана"):
            assert calendar_page.get_date_value() == "2025-12-31"
            assert not calendar_page.field_has_error(timeout=1)

    @pytest.mark.positive
    @allure.story("Отправка формы")
    @allure.title("CAL-P5: форма с датой, выбранной в календаре, успешно отправляется")
    def test_submit_date_selected_in_picker(self, calendar_page):
        today = date.today()
        calendar_page.select_date(date(today.year, today.month, 10))
        calendar_page.submit()
        with allure.step("Появилось сообщение «Thank you for your response»"):
            assert calendar_page.wait_form_success(), "Сообщение об успешной отправке не появилось"

    @pytest.mark.positive
    @allure.story("Отправка формы")
    @allure.title("CAL-P6: форма с високосной датой 2024-02-29, введённой вручную, успешно отправляется")
    def test_submit_typed_leap_day(self, calendar_page):
        calendar_page.type_date("2024-02-29")
        calendar_page.submit()
        with allure.step("Появилось сообщение «Thank you for your response»"):
            assert calendar_page.wait_form_success(), "Сообщение об успешной отправке не появилось"

    @pytest.mark.positive
    @allure.story("Подсветка в календаре")
    @allure.title("CAL-P7: сегодняшний день подсвечен в календаре")
    def test_today_is_highlighted(self, calendar_page):
        calendar_page.open_picker()
        with allure.step("Подсвеченная ячейка содержит сегодняшнее число"):
            assert calendar_page.text_of(calendar_page.today_cell()) == str(date.today().day)

    @pytest.mark.positive
    @allure.story("Подсветка в календаре")
    @allure.title("CAL-P8: при повторном открытии подсвечен ранее выбранный день")
    def test_selected_day_is_highlighted_on_reopen(self, calendar_page):
        today = date.today()
        calendar_page.select_date(date(today.year, today.month, 12))
        calendar_page.open_picker()
        with allure.step("Подсвеченная ячейка — 12-е число"):
            assert calendar_page.text_of(calendar_page.selected_cell()) == "12"


@allure.epic("practice-automation.com")
@allure.feature("Календарь")
class TestCalendarNegative:

    @pytest.mark.negative
    @allure.story("Некорректный ввод")
    @pytest.mark.parametrize(
        "bad_value",
        ["abcXYZ", "31/12/2024", "2025-02-30"],
        ids=["letters", "slash-format", "nonexistent-date"],
    )
    @allure.title("CAL-N1: некорректная дата «{bad_value}» помечается ошибкой")
    def test_invalid_date_shows_error(self, calendar_page, bad_value):
        calendar_page.type_date(bad_value)
        calendar_page.leave_field()
        with allure.step("У поля даты показана ошибка валидации"):
            assert calendar_page.field_has_error(), f"Для значения '{bad_value}' ошибка не показана"

    @pytest.mark.negative
    @allure.story("Отправка формы")
    @allure.title("CAL-N2: форма с некорректной датой не отправляется")
    def test_submit_invalid_date_is_blocked(self, calendar_page):
        calendar_page.type_date("not-a-date")
        calendar_page.submit()
        with allure.step("Сообщения об успешной отправке нет, у поля показана ошибка"):
            assert not calendar_page.wait_form_success(timeout=3)
            assert calendar_page.field_has_error()

    @pytest.mark.negative
    @allure.story("Отправка формы")
    @allure.title("CAL-N3: пустая форма не отправляется")
    def test_submit_empty_form_is_blocked(self, calendar_page):
        calendar_page.submit()
        with allure.step("Сообщения об успешной отправке нет"):
            assert not calendar_page.wait_form_success(timeout=3)
