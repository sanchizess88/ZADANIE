"""Тесты страницы «Рекламные окна»: https://practice-automation.com/ads/"""
import allure
import pytest

pytestmark = pytest.mark.ads


@allure.epic("practice-automation.com")
@allure.feature("Рекламные окна")
class TestAdsPositive:

    @pytest.mark.positive
    @allure.story("Появление рекламы")
    @allure.title("ADS-P1: рекламное окно появляется через несколько секунд после загрузки")
    def test_ad_appears_after_delay(self, ads_page):
        ads_page.wait_ad(timeout=15)
        with allure.step("Рекламное окно отображается"):
            assert ads_page.is_ad_displayed()

    @pytest.mark.positive
    @allure.story("Содержимое рекламы")
    @allure.title("ADS-P2: в рекламном окне есть заголовок «Hi»")
    def test_ad_has_title(self, ads_page):
        ads_page.wait_ad()
        with allure.step("Заголовок «Hi» отображается"):
            assert ads_page.text_of(ads_page.ad_title()) == "Hi"

    @pytest.mark.positive
    @allure.story("Содержимое рекламы")
    @allure.title("ADS-P3: в рекламном окне есть текст «I am an ad»")
    def test_ad_has_body_text(self, ads_page):
        with allure.step("Текст рекламы содержит «I am an ad»"):
            assert "I am an ad" in ads_page.ad_text()

    @pytest.mark.positive
    @allure.story("Содержимое рекламы")
    @allure.title("ADS-P4: в рекламном окне есть кнопка закрытия «×»")
    def test_ad_has_close_button(self, ads_page):
        with allure.step("Кнопка закрытия отображается"):
            assert ads_page.ad_close_button().is_displayed()

    @pytest.mark.positive
    @allure.story("Закрытие рекламы")
    @allure.title("ADS-P5: рекламное окно закрывается кнопкой «×»")
    def test_ad_closes(self, ads_page):
        ads_page.wait_ad()
        ads_page.close_ad()
        with allure.step("Рекламное окно больше не отображается"):
            assert not ads_page.is_ad_displayed()

    @pytest.mark.positive
    @allure.story("Закрытие рекламы")
    @allure.title("ADS-P6: после закрытия рекламы содержимое страницы доступно (не перекрыто)")
    def test_page_content_available_after_closing_ad(self, ads_page):
        ads_page.wait_ad()
        ads_page.close_ad()
        with allure.step("Заголовок страницы не перекрыт оверлеем"):
            assert ads_page.is_page_content_available()

    @pytest.mark.positive
    @allure.story("Содержимое страницы")
    @allure.title("ADS-P7: на странице есть описание с обратным отсчётом до рекламы")
    def test_countdown_text_is_present(self, ads_page):
        with allure.step("Текст «An ad will appear in …» отображается"):
            assert "An ad will appear in" in ads_page.text_of(ads_page.countdown_element())

    @pytest.mark.positive
    @allure.story("Содержимое страницы")
    @allure.title("ADS-P8: ссылка «how to handle ads in test automation» ведёт на YouTube")
    def test_how_to_link_points_to_youtube(self, ads_page):
        with allure.step("Атрибут href ссылки содержит youtube.com"):
            assert "youtube.com" in ads_page.how_to_link().get_attribute("href")


@allure.epic("practice-automation.com")
@allure.feature("Рекламные окна")
class TestAdsNegative:

    @pytest.mark.negative
    @allure.story("Появление рекламы")
    @allure.title("ADS-N1: реклама не показывается сразу после открытия страницы")
    def test_ad_is_not_shown_immediately(self, ads_page):
        with allure.step("Сразу после загрузки рекламного окна нет"):
            assert not ads_page.is_ad_displayed()

    @pytest.mark.negative
    @allure.story("Закрытие рекламы")
    @allure.title("ADS-N2: клик по содержимому рекламы не закрывает окно")
    def test_click_inside_ad_does_not_close_it(self, ads_page):
        ads_page.wait_ad()
        ads_page.click_inside_ad()
        with allure.step("Рекламное окно остаётся открытым"):
            assert ads_page.ad_stays_displayed(seconds=2)

    @pytest.mark.negative
    @allure.story("Перекрытие страницы")
    @allure.title("ADS-N3: пока реклама открыта, содержимое страницы перекрыто")
    def test_page_content_is_blocked_while_ad_is_open(self, ads_page):
        ads_page.wait_ad()
        with allure.step("Заголовок страницы перекрыт рекламным окном/оверлеем"):
            assert not ads_page.is_page_content_available()

    @pytest.mark.negative
    @allure.story("Закрытие рекламы")
    @allure.title("ADS-N4: закрытая реклама повторно не появляется")
    def test_closed_ad_does_not_reappear(self, ads_page):
        ads_page.wait_ad()
        ads_page.close_ad()
        with allure.step("В течение 7 секунд реклама не появляется снова"):
            assert ads_page.ad_stays_hidden(seconds=7), "Закрытая реклама появилась повторно"
