"""Тесты страницы с формой: https://practice-automation.com/form-fields/

Здесь же реализован пункт 5 задания: поле Message заполняется списком
из раздела «Automation tools», полученным средствами Selenium.
"""
import allure
import pytest

pytestmark = pytest.mark.form

EXPECTED_TOOLS = ["Selenium", "Playwright", "Cypress", "Appium", "Katalon Studio"]


@allure.epic("practice-automation.com")
@allure.feature("Форма (Form Fields)")
class TestFormFields:

    @pytest.mark.positive
    @allure.story("Automation tools")
    @allure.title("FORM-P1: из раздела «Automation tools» считывается ожидаемый список инструментов")
    def test_automation_tools_list(self, form_page):
        tools = form_page.get_automation_tools()
        with allure.step(f"Получен список: {tools}"):
            assert tools == EXPECTED_TOOLS

    @pytest.mark.positive
    @allure.story("Automation tools")
    @allure.title("FORM-P2: поле Message заполняется списком Automation tools через запятую")
    def test_message_filled_with_automation_tools(self, form_page):
        expected = ", ".join(EXPECTED_TOOLS)
        filled = form_page.fill_message_with_automation_tools()
        with allure.step(f"В поле Message записано: {expected}"):
            assert filled == expected
            assert form_page.message_value() == expected

    @pytest.mark.positive
    @allure.story("Отправка формы")
    @allure.title("FORM-P3: полностью заполненная форма отправляется, появляется alert «Message received!»")
    def test_submit_filled_form_shows_alert(self, form_page):
        form_page.fill_name("Ivan Petrov")
        form_page.fill_password("Str0ng-Passw0rd!")
        form_page.choose_drink("Coffee")
        form_page.choose_color("Blue")
        form_page.choose_automation_answer("Yes")
        form_page.fill_email("ivan.petrov@example.com")
        form_page.fill_message_with_automation_tools()
        form_page.submit()
        alert_text = form_page.accept_alert()
        with allure.step(f"Текст alert: {alert_text}"):
            assert alert_text is not None, "Alert после отправки формы не появился"
            assert "Message received" in alert_text

    @pytest.mark.positive
    @allure.story("Элементы формы")
    @allure.title("FORM-P4: чекбоксы, радиокнопка и выпадающий список принимают выбор")
    def test_choose_controls(self, form_page):
        milk = form_page.choose_drink("Milk")
        coffee = form_page.choose_drink("Coffee")
        blue = form_page.choose_color("Blue")
        selected_answer = form_page.choose_automation_answer("Undecided")
        with allure.step("Выбранные значения отображаются как выбранные"):
            assert milk.is_selected() and coffee.is_selected()
            assert blue.is_selected()
            assert selected_answer == "Undecided"

    @pytest.mark.negative
    @allure.story("Валидация формы")
    @allure.title("FORM-N1: форма без обязательного поля Name не отправляется (alert не появляется)")
    def test_submit_without_name_does_not_show_alert(self, form_page):
        form_page.fill_email("ivan.petrov@example.com")
        form_page.fill_message_with_automation_tools()
        form_page.submit()
        with allure.step("Alert об успешной отправке не появился"):
            assert form_page.accept_alert(timeout=3) is None
