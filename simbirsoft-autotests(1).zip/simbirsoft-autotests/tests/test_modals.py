"""Тесты страницы «Модальные окна»: https://practice-automation.com/modals/"""
import allure
import pytest

pytestmark = pytest.mark.modals

VALID_NAME = "Ivan Petrov"
VALID_EMAIL = "ivan.petrov@example.com"
VALID_MESSAGE = "Автотест: проверка формы в модальном окне"


@allure.epic("practice-automation.com")
@allure.feature("Модальные окна")
class TestModalsPositive:

    @pytest.mark.positive
    @allure.story("Простое модальное окно")
    @allure.title("MOD-P1: простое модальное окно открывается и содержит ожидаемый текст")
    def test_simple_modal_opens(self, modals_page):
        modals_page.open_simple_modal()
        with allure.step("В окне есть текст «simple modal»"):
            assert "simple modal" in modals_page.popup_text(modals_page.SIMPLE_TEXT).lower()

    @pytest.mark.positive
    @allure.story("Простое модальное окно")
    @allure.title("MOD-P2: простое модальное окно закрывается кнопкой «×»")
    def test_simple_modal_closes(self, modals_page):
        modals_page.open_simple_modal()
        modals_page.close_simple_modal()
        with allure.step("Окно больше не отображается"):
            assert not modals_page.is_simple_modal_displayed()

    @pytest.mark.positive
    @allure.story("Простое модальное окно")
    @allure.title("MOD-P3: простое модальное окно можно открыть повторно после закрытия")
    def test_simple_modal_reopens(self, modals_page):
        modals_page.open_simple_modal()
        modals_page.close_simple_modal()
        modals_page.open_simple_modal()
        with allure.step("Окно снова отображается"):
            assert modals_page.is_simple_modal_displayed()

    @pytest.mark.positive
    @allure.story("Модальное окно с формой")
    @allure.title("MOD-P4: окно с формой открывается и показывает приглашение ввести контакты")
    def test_form_modal_opens(self, modals_page):
        modals_page.open_form_modal()
        with allure.step("В окне есть текст «Please enter your contact info below»"):
            text = modals_page.popup_text(modals_page.FORM_TEXT)
            assert "Please enter your contact info below" in text

    @pytest.mark.positive
    @allure.story("Модальное окно с формой")
    @allure.title("MOD-P5: в окне с формой есть поля Name, Email, Message и кнопка Submit")
    def test_form_modal_has_all_fields(self, modals_page):
        modals_page.open_form_modal()
        fields = modals_page.form_elements()
        with allure.step("Все элементы формы отображаются"):
            assert all(element.is_displayed() for element in fields.values())

    @pytest.mark.positive
    @allure.story("Модальное окно с формой")
    @allure.title("MOD-P6: окно с формой закрывается кнопкой «×»")
    def test_form_modal_closes(self, modals_page):
        modals_page.open_form_modal()
        modals_page.close_form_modal()
        with allure.step("Окно больше не отображается"):
            assert not modals_page.is_form_modal_displayed()

    @pytest.mark.positive
    @allure.story("Модальное окно с формой")
    @allure.title("MOD-P7: поля формы принимают введённые значения")
    def test_form_modal_accepts_input(self, modals_page):
        modals_page.open_form_modal()
        modals_page.fill_form_modal(VALID_NAME, VALID_EMAIL, VALID_MESSAGE)
        with allure.step("Значения в полях совпадают с введёнными"):
            assert modals_page.form_values() == {
                "name": VALID_NAME,
                "email": VALID_EMAIL,
                "message": VALID_MESSAGE,
            }

    @pytest.mark.positive
    @allure.story("Отправка формы")
    @allure.title("MOD-P8: форма с заполненными Name, Email и Message успешно отправляется")
    def test_form_modal_submit_all_fields(self, modals_page):
        modals_page.open_form_modal()
        modals_page.fill_form_modal(VALID_NAME, VALID_EMAIL, VALID_MESSAGE)
        modals_page.submit_form_modal()
        with allure.step("Появилось сообщение «Thank you for your response»"):
            assert modals_page.wait_form_success(), "Сообщение об успешной отправке не появилось"

    @pytest.mark.positive
    @allure.story("Отправка формы")
    @allure.title("MOD-P9: форма с одним обязательным полем Name успешно отправляется")
    def test_form_modal_submit_only_required_field(self, modals_page):
        modals_page.open_form_modal()
        modals_page.fill_form_modal(name=VALID_NAME)
        modals_page.submit_form_modal()
        with allure.step("Появилось сообщение «Thank you for your response»"):
            assert modals_page.wait_form_success(), "Сообщение об успешной отправке не появилось"


@allure.epic("practice-automation.com")
@allure.feature("Модальные окна")
class TestModalsNegative:

    @pytest.mark.negative
    @allure.story("Видимость окон")
    @allure.title("MOD-N1: модальные окна не отображаются сразу после загрузки страницы")
    def test_modals_hidden_on_load(self, modals_page):
        with allure.step("Ни простое окно, ни окно с формой не видны"):
            assert not modals_page.is_simple_modal_displayed()
            assert not modals_page.is_form_modal_displayed()

    @pytest.mark.negative
    @allure.story("Видимость окон")
    @allure.title("MOD-N2: при открытии простого окна окно с формой не показывается")
    def test_simple_modal_does_not_show_form_modal(self, modals_page):
        modals_page.open_simple_modal()
        with allure.step("Окно с формой остаётся скрытым"):
            assert not modals_page.is_form_modal_displayed()

    @pytest.mark.negative
    @allure.story("Валидация формы")
    @allure.title("MOD-N3: форма без обязательного поля Name не отправляется")
    def test_form_modal_without_name_is_not_submitted(self, modals_page):
        modals_page.open_form_modal()
        modals_page.fill_form_modal(email=VALID_EMAIL, message=VALID_MESSAGE)
        modals_page.submit_form_modal()
        with allure.step("Сообщения об успехе нет, у поля Name показана ошибка, окно осталось открытым"):
            assert not modals_page.wait_form_success(timeout=3)
            assert modals_page.has_field_errors()
            assert modals_page.is_form_modal_displayed()

    @pytest.mark.negative
    @allure.story("Валидация формы")
    @allure.title("MOD-N4: форма с некорректным Email не отправляется")
    def test_form_modal_with_invalid_email_is_not_submitted(self, modals_page):
        modals_page.open_form_modal()
        modals_page.fill_form_modal(name=VALID_NAME, email="not-an-email")
        modals_page.submit_form_modal()
        with allure.step("Сообщения об успехе нет"):
            assert not modals_page.wait_form_success(timeout=3)
