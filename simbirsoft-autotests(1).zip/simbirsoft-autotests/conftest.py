"""Фикстуры pytest: создание драйвера, page object'ов и скриншоты при падении тестов."""
import os

import allure
import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.firefox.options import Options as FirefoxOptions

from pages.ads_page import AdsPage
from pages.calendar_page import CalendarPage
from pages.form_fields_page import FormFieldsPage
from pages.modals_page import ModalsPage


def pytest_addoption(parser):
    parser.addoption(
        "--browser",
        action="store",
        default=os.getenv("BROWSER", "chrome"),
        choices=("chrome", "firefox"),
        help="Браузер для запуска тестов: chrome (по умолчанию) или firefox",
    )
    parser.addoption(
        "--headless",
        action="store_true",
        default=os.getenv("HEADLESS", "0") == "1",
        help="Запуск браузера без графического окна",
    )


def _create_driver(browser: str, headless: bool):
    if browser == "firefox":
        options = FirefoxOptions()
        if headless:
            options.add_argument("-headless")
        driver = webdriver.Firefox(options=options)
    else:
        options = ChromeOptions()
        options.add_argument("--disable-notifications")
        options.add_argument("--disable-search-engine-choice-screen")
        if headless:
            options.add_argument("--headless=new")
            options.add_argument("--no-sandbox")
            options.add_argument("--disable-dev-shm-usage")
        driver = webdriver.Chrome(options=options)
    driver.set_window_size(1920, 1080)
    return driver


@pytest.fixture
def driver(request):
    """Новый чистый браузер на каждый тест (тесты не влияют друг на друга)."""
    browser = request.config.getoption("--browser")
    headless = request.config.getoption("--headless")
    with allure.step(f"Запустить браузер {browser} (headless={headless})"):
        drv = _create_driver(browser, headless)
    yield drv
    drv.quit()


@pytest.fixture
def calendar_page(driver):
    return CalendarPage(driver).open()


@pytest.fixture
def modals_page(driver):
    return ModalsPage(driver).open()


@pytest.fixture
def ads_page(driver):
    return AdsPage(driver).open()


@pytest.fixture
def form_page(driver):
    return FormFieldsPage(driver).open()


def _attach_failure_artifacts(driver) -> None:
    try:
        try:
            driver.switch_to.alert.dismiss()  # открытый alert мешает сделать скриншот
        except Exception:
            pass
        allure.attach(
            driver.get_screenshot_as_png(),
            name="Скриншот при ошибке",
            attachment_type=allure.attachment_type.PNG,
        )
        allure.attach(driver.current_url, name="URL страницы", attachment_type=allure.attachment_type.TEXT)
        allure.attach(driver.page_source, name="HTML страницы", attachment_type=allure.attachment_type.HTML)
    except Exception as exc:  # сбор артефактов не должен ломать прогон
        print(f"Не удалось приложить артефакты к отчёту: {exc}")


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """При падении теста прикладываем скриншот к Allure-отчёту."""
    outcome = yield
    report = outcome.get_result()
    if report.when in ("setup", "call") and report.failed:
        driver = item.funcargs.get("driver")
        if driver is not None:
            _attach_failure_artifacts(driver)
